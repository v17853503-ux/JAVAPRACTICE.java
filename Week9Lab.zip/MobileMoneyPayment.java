public class MobileMoneyPayment implements Payable {
    @Override
    public void pay(double amount) {
        System.out.println("Processing mobile money payment of $" + amount);
    }
}
