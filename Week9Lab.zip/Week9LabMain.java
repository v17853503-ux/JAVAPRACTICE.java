public class Week9LabMain {
    public static void main(String[] args) {
        System.out.println("=== PART A: Shape Hierarchy & Polymorphism ===");
        try {
            Shape[] shapes = {
                new Circle(5.0),
                new Rectangle(4.0, 6.0)
            };

            for (Shape s : shapes) {
                if (s instanceof Circle) {
                    System.out.print("Circle area: ");
                } else if (s instanceof Rectangle) {
                    System.out.print("Rectangle area: ");
                }
                s.printArea();
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation Error: " + e.getMessage());
        }

        System.out.println("\n=== PART B: Payment Interface & Polymorphism ===");
        Payable[] payments = {
            new CardPayment(),
            new MobileMoneyPayment()
        };

        for (Payable p : payments) {
            p.pay(250.0);
        }
    }
}
