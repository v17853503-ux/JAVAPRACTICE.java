public class CardPayment implements Payable {
    @Override
    public void pay(double amount) {
        System.out.println("Processing credit/debit card payment of $" + amount);
    }
}
